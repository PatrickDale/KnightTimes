//
//  ViewController.h
//  HomePageExample
//
//  Created by Pat Dale on 4/30/14.
//  Copyright (c) 2014 4students2apps. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIView *storyOneView;
@property (weak, nonatomic) IBOutlet UIView *storyTwoView;
@property (weak, nonatomic) IBOutlet UIView *storyThreeView;
@property (weak, nonatomic) IBOutlet UIView *storyFourView;
@property (weak, nonatomic) IBOutlet UIView *storyFiveView;
@property (weak, nonatomic) IBOutlet UIView *storySixView;
@property (weak, nonatomic) IBOutlet UIView *storySevenView;
@property (weak, nonatomic) IBOutlet UIView *storyEightView;
@property (weak, nonatomic) IBOutlet UIView *storyNineView;
@property (weak, nonatomic) IBOutlet UIView *storyTenView;
@property (weak, nonatomic) IBOutlet UIView *storyElevenView;
@property (weak, nonatomic) IBOutlet UIView *storyTwelveView;
@property (weak, nonatomic) IBOutlet UIView *storyThirteenView;
@property (weak, nonatomic) IBOutlet UIView *storyFourteenView;
@property (weak, nonatomic) IBOutlet UIImageView *storyImage;

- (IBAction)returnToHome:(id)sender;
- (IBAction)gestureRecognized:(id)sender;

@end

